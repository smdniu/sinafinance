package cn.mrsunflower.sinafinancecashfei.pojo;

import lombok.*;

import javax.annotation.Generated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
/**
 * 用户绑定的银行
 */
@Table(name = "withdrawal_bank")
public class WithdrawalBank {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;
  //用户ID
  private Long uid;
  //中文名
  private String cnname;
  //卡的缩写 例如ICBC
  private String bankCode;
  //银行名
  private String bankName;
  //卡号
  private String bankNumber;
  //排序用,从小到大
  private Long sequence;
  //创建时间
  private java.sql.Timestamp createTime;

}
