package cn.mrsunflower.sinafinancecashfei.mapper;

import cn.mrsunflower.sinafinancecashfei.pojo.Withdrawal;
import tk.mybatis.mapper.common.Mapper;

//整合通用mapper
public interface WithdrawalMapper extends Mapper<Withdrawal> {
}
