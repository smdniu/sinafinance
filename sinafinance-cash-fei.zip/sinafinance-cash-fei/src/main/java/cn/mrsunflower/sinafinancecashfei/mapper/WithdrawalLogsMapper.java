package cn.mrsunflower.sinafinancecashfei.mapper;

import cn.mrsunflower.sinafinancecashfei.pojo.Withdrawal;
import cn.mrsunflower.sinafinancecashfei.pojo.WithdrawalLogs;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

//整合通用mapper
public interface WithdrawalLogsMapper extends Mapper<WithdrawalLogs> {
}
