package cn.mrsunflower.sinafinancecashfei.mapper;

import cn.mrsunflower.sinafinancecashfei.pojo.WithdrawalBank;
import tk.mybatis.mapper.common.Mapper;

public interface WithdrawalBankMapper extends Mapper<WithdrawalBank> {
}
