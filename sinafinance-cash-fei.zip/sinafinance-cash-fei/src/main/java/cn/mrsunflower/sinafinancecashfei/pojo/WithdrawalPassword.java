package cn.mrsunflower.sinafinancecashfei.pojo;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
/**
 * 支付密码
 */
public class WithdrawalPassword {

  private long id;
  private long uid;
  private String password;
  private java.sql.Timestamp createTime;
  private java.sql.Timestamp lastUpdateTime;
}
