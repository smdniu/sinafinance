package cn.mrsunflower.sinafinancecashfei.controller;

import cn.mrsunflower.sinafinancecashfei.pojo.Withdrawal;
import cn.mrsunflower.sinafinancecashfei.pojo.WithdrawalBank;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestController {
    @GetMapping("test")
    public WithdrawalBank test() {
        return new WithdrawalBank();
    }

    @GetMapping("test2")
    public Withdrawal test1() {
        return new Withdrawal();
    }
}
