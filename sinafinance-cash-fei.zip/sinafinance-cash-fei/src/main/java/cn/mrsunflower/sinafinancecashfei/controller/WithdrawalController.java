package cn.mrsunflower.sinafinancecashfei.controller;

import cn.mrsunflower.sinafinancecashfei.pojo.Withdrawal;
import cn.mrsunflower.sinafinancecashfei.pojo.WithdrawalLogs;
import cn.mrsunflower.sinafinancecashfei.service.PreWithdrawal;
import cn.mrsunflower.sinafinancecashfei.service.WithdrawalService;
import com.alipay.api.domain.Money;
import com.sinafinance.enums.ResponseCode;
import com.sinafinance.enums.WithdrawalConstant;
import com.sinafinance.vo.BaseResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@RestController
public class WithdrawalController {
    @Autowired
    private PreWithdrawal preWithdrawal;

    @Autowired
    private WithdrawalService withdrawalService;


    /**
     * 提现金额计算
     */
    @GetMapping(value = "/withdrawal/count")
    public BaseResponse countWithdraw(HttpServletRequest request, HttpServletResponse response,
                                      long withdrawApply, Long userId) {
        //logger.info("WithdrawalController.countWithdraw.start");
        try {
            Map map = preWithdrawal.countWithdraw(withdrawApply, userId);

            //创建结果返回值
            BaseResponse baseResponse = new BaseResponse();
            baseResponse.setRespCode("20000");
            baseResponse.setRespMsg("计算成功");
            baseResponse.setResult(map);

            return baseResponse;
        } catch (Exception ex) {
            ex.printStackTrace();
            return new BaseResponse().newFailResponse("50005", "系统错误,请重试");
        }
    }

    /* 提现申请 */
    @RequestMapping(value = "/withdrawal/apply", method = {RequestMethod.GET, RequestMethod.POST})
    public BaseResponse applyWithDrawal(HttpServletRequest request, HttpServletResponse response,
                                        @RequestBody Withdrawal withdrawal) {
        System.out.println(withdrawal);
        //  logger.info("WithdrawalController.applyWithDrawal.start");
        try {
            Long userId = withdrawal.getUid();
            if (userId == null) {
                return new BaseResponse().newFailResponse(ResponseCode.PARAMETER_ERROR.getCode(), "参数错误");
            }
            // 查询提现表中是否存在当前用户正在审核的提现，如果存在就不允许继续申请
            Withdrawal withdrawalByUserId = withdrawalService.getWithdrawalByUserId(userId);
            if (withdrawalByUserId != null) {
                return new BaseResponse().newFailResponse(ResponseCode.ERROR.getCode(), "已有提现记录,正在审核中!");
            }
            //------------------
            /**
             * 可提现金额=帐户金额-手续费-转账金额(红包金额)
             * ps:这里可以使用上面的uid查询可转账余额
             */
            System.out.println("------查询用户可提现金额-------");
            //假如这里只有2000块可以提现的了
            BigDecimal billMoney = new BigDecimal(2000L);

            //------------------

            //logger.info("[WithdrawalController][applyWithDrawal]当前用户userId:" + userId + " 可提现金额:" + billMoney);            // 卖家申请提现金额;
            BigDecimal withdrawApplyTotal = withdrawal.getWithdrawApplyTotal();

            //logger.info("[WithdrawalController][applyWithDrawal]当前用户userId:" + userId + " 申请的提现金额:" + withdrawApplyTotal);            // 如果申请的金额大于系统的金额，则返回1，同时不符合逻辑，直接返回error
            if (withdrawApplyTotal.compareTo(billMoney) == 1) {
                return new BaseResponse().newFailResponse(ResponseCode.ERROR.getCode(), "申请金额错误,返回重试!");
            }

            //生成提现订单号,可以使用使用推特的雪花算法生成,我这里随便弄的一个UUID
            withdrawal.setWithdrawApplyTime(new Timestamp(System.currentTimeMillis()));
            String orderNumber = UUID.randomUUID().toString();
            withdrawal.setWithdrawOrder(orderNumber);
            //添加创建时间
            withdrawal.setCreateTime(new Timestamp(System.currentTimeMillis()));
            // 申请提现.修改提现订单状态
            withdrawal.setStatus(WithdrawalConstant.APPLY_WITHDRAWAL.getStatus());



            //提现日志
            WithdrawalLogs withdrawalLogs = new WithdrawalLogs();
            withdrawalLogs.setWithdrawOrder(orderNumber);
            withdrawalLogs.setCreateTime(new Timestamp(System.currentTimeMillis()));
            withdrawalLogs.setStatus(WithdrawalConstant.APPLY_WITHDRAWAL.getStatus());
            withdrawalLogs.setCreateBy(userId);
            withdrawalLogs.setUid(userId);
            withdrawalLogs.setRemark("提现已提交,审核中!");
            //记录提现日志和提现order
            withdrawalService.applyWithdrawal(withdrawal, withdrawalLogs);

            /**
             *发送消息通知
             * ps:这里没有实现,有空可以实现一下
             */
            //sendSmsNotice(withdrawal, userId, seller, billMoney, withdrawApplyTotal);

            BaseResponse baseResponse = new BaseResponse();
            baseResponse.setRespCode(ResponseCode.SUCCESS.getCode());
            baseResponse.setRespMsg("申请提现成功");

            return baseResponse;
        } catch (Exception ex) {
            ex.printStackTrace();
            //logger.error("[WithdrawalController][applyWithDrawal]exception ", ex);
            return new BaseResponse().newFailResponse(ResponseCode.SYSTEM_ERROR.getCode(), "申请失败，系统异常，请稍后再试");
        }
    }
}
