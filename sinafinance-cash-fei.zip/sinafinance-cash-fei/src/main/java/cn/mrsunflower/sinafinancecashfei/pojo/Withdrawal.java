package cn.mrsunflower.sinafinancecashfei.pojo;

import lombok.*;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.math.BigDecimal;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
/**
 * 提现信息
 */
@Table(name = "withdrawal")
public class Withdrawal {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    //提现申请人ID
    private long uid;
    //提现订单号,系统自动生成的
    private String withdrawOrder;
    //用户对应的卡的编号
    private long withdrawBankId;
    //提现手续费
    private BigDecimal withdrawCharge;
    //实际提现金额
    private BigDecimal withdrawRealityTotal;
    //申请提现的金额
    private BigDecimal withdrawApplyTotal;
    //申请提现的时间
    private java.sql.Timestamp withdrawApplyTime;
    /**
     * 提现状态:
     *    1表示申请提现
     *    2表示审批通过
     *    3交易完成
     *
     *    -1审批不通过.
     */
    private long status;
    //创建人ID
    private long createBy;
    //修改时间
    private java.sql.Timestamp createTime;
    //修改人ID
    private long updateBy;
    //最后一次修改的时间
    private java.sql.Timestamp lastUpdateTime;

}
