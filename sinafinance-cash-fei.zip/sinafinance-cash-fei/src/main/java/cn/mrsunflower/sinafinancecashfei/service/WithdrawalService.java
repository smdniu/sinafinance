package cn.mrsunflower.sinafinancecashfei.service;

import cn.mrsunflower.sinafinancecashfei.mapper.WithdrawalLogsMapper;
import cn.mrsunflower.sinafinancecashfei.mapper.WithdrawalMapper;
import cn.mrsunflower.sinafinancecashfei.pojo.Withdrawal;
import cn.mrsunflower.sinafinancecashfei.pojo.WithdrawalLogs;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@SuppressWarnings("all")
@Service
public class WithdrawalService {
    @Autowired
    private WithdrawalMapper withdrawalMapper;
    @Autowired
    private WithdrawalLogsMapper withdrawalLogsMapper;

    public Withdrawal getWithdrawalByUserId(Long userId) {
        Withdrawal withdrawal = withdrawalMapper.selectByPrimaryKey(userId);
        return withdrawal;
    }

    public void applyWithdrawal(Withdrawal withdrawal, WithdrawalLogs withdrawalLogs) {

        withdrawalMapper.insert(withdrawal);
        withdrawalLogsMapper.insert(withdrawalLogs);
    }
}
