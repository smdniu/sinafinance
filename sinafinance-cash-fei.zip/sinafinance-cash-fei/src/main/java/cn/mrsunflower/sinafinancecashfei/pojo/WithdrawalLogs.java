package cn.mrsunflower.sinafinancecashfei.pojo;

import lombok.*;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
/**
 * 提现的日志
 */
@Table(name = "withdrawal_logs")
public class WithdrawalLogs {
  //id
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long id;
  //提现申请人
  private long uid;
  //提现订单号,系统自动生成
  private String withdrawOrder;
  //备注
  private String remark;
  //提现的状态
  private long status;
  //创建人
  private long createBy;
  //创建时间
  private java.sql.Timestamp createTime;
}
