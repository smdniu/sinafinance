package cn.mrsunflower.sinafinancecashfei;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SinafinanceCashFeiApplicationTests {

    @Test
    void contextLoads() {
    }

}
